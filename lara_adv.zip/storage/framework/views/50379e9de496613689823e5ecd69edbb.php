<?php $__env->startSection('title'); ?> login activity <?php $__env->stopSection(); ?>

<?php $__env->startPush('admin_style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('index'); ?>

<div class="row">

    <div class="col-lg-4 col-md-4 col-4 mb-4">

        <div class="card">
          <div class="card-body">
            <div class="card-title d-flex align-items-start justify-content-between">
              <div class="avatar flex-shrink-0">
                <img src="<?php echo e(asset('admin')); ?>/assets/img/icons/unicons/chart-success.png" alt="chart success" class="rounded">
              </div>
              <div class="dropdown">
                <button class="btn p-0" type="button" id="cardOpt3" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3" style="">
                  <a class="dropdown-item" href="javascript:void(0);">View More</a>
                  <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                </div>
              </div>
            </div>
            <span class="fw-semibold d-block mb-1">Total User</span>
            <h3 class="card-title mb-2"><?php echo e($user_count); ?></h3>

          </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-4 col-4 mb-4">

        <div class="card">
          <div class="card-body">
            <div class="card-title d-flex align-items-start justify-content-between">
              <div class="avatar flex-shrink-0">
                <img src="<?php echo e(asset('admin')); ?>/assets/img/icons/unicons/chart-success.png" alt="chart success" class="rounded">
              </div>
              <div class="dropdown">
                <button class="btn p-0" type="button" id="cardOpt3" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3" style="">
                  <a class="dropdown-item" href="javascript:void(0);">View More</a>
                  <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                </div>
              </div>
            </div>
            <span class="fw-semibold d-block mb-1">Total Role</span>
            <h3 class="card-title mb-2"><?php echo e($role_count); ?></h3>

          </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-4 col-4 mb-4">

        <div class="card">
          <div class="card-body">
            <div class="card-title d-flex align-items-start justify-content-between">
              <div class="avatar flex-shrink-0">
                <img src="<?php echo e(asset('admin')); ?>/assets/img/icons/unicons/chart-success.png" alt="chart success" class="rounded">
              </div>
              <div class="dropdown">
                <button class="btn p-0" type="button" id="cardOpt3" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3" style="">
                  <a class="dropdown-item" href="javascript:void(0);">View More</a>
                  <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                </div>
              </div>
            </div>
            <span class="fw-semibold d-block mb-1">Total Page</span>
            <h3 class="card-title mb-2"><?php echo e($page_count); ?></h3>

          </div>
        </div>
    </div>
</div>

<div class="row">
   <div class="col-12">

    <div class="table-responsive text-nowrap">
        <table class="table table-hover">
          <thead>
            <tr>
              <th>ID</th>
              <th>User ID</th>
              <th>User Name</th>
              <th>User Email</th>
              <th>Last Activity</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">

              <?php $__empty_1 = true; $__currentLoopData = $user_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

              <tr>
                  <td><strong><?php echo e($value->id); ?></strong></td>
                  <td><?php echo e($value->user_id); ?></td>
                  <td><?php echo e($value->name); ?></td>
                  <td><?php echo e($value->email); ?></td>
                  <td><span class="badge bg-label-primary me-1"><?php echo e($value->created_at->format('d-m-Y')); ?> / <?php echo e($value->created_at->diffForHumans()); ?></span></td>

                  <td>
                    <div class="dropdown">
                      <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bx bx-dots-vertical-rounded"></i>
                      </button>
                      <div class="dropdown-menu" style="">

                        <a class="dropdown-item" href="<?php echo e(route('user.edit',$value->id)); ?>"><i class="bx bx-edit-alt me-1"></i> Edit</a>




                          <form action="<?php echo e(route('user.destroy',$value->id)); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>

                              <button type="submit" class="dropdown-item show_confirm" ><i class="bx bx-trash me-1"></i> Delete</button>

                          </form>

                      </div>
                    </div>
                  </td>
                </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

              <?php endif; ?>



          </tbody>
        </table>

        <div class="my-2 p-3">
          <?php echo e($user_data->links()); ?>

        </div>

    </div>

   </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('admin_script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\lara_adv\lara_adv\resources\views/admin/layout/inc/home.blade.php ENDPATH**/ ?>