<footer class="content-footer footer bg-footer-theme">
    <div
        class="container-xxl d-flex flex-wrap justify-content-center py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
                document.write(new Date().getFullYear());
            </script>
            , made with ❤️ by ITman corporation

        </div>

    </div>
</footer>
<?php /**PATH H:\lara_adv\lara_adv\resources\views/admin/layout/inc/footer.blade.php ENDPATH**/ ?>