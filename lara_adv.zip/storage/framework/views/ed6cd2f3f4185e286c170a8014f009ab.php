<?php $__env->startSection('title'); ?> role <?php $__env->stopSection(); ?>
<?php $__env->startPush('admin_style'); ?>



<?php $__env->stopPush(); ?>

<?php $__env->startSection('index'); ?>

<div class="row">
    <div class="col">


<div class="card">

    <div class="d-flex justify-content-between align-items-center my-2">

        <h5 class="card-header">Role Index / Role List</h5>
        <a href="<?php echo e(route('role.create')); ?>" class="btn btn-primary me-4">Add New</a>

    </div>

    <div class="table-responsive text-nowrap">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>ID</th>
            <th>Role Name</th>
            <th>Permission Slug</th>
            <th>Last Update</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody class="table-border-bottom-0">

            <?php $__empty_1 = true; $__currentLoopData = $role_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>
                <td><strong><?php echo e($value->id); ?></strong></td>
                <td><?php echo e($value->role_name); ?></td>
                <td>

                    <?php $__currentLoopData = $value->permissions->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chunk_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <div class="">

                        <?php $__currentLoopData = $chunk_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-success"><?php echo e($permission->permission_slug); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                      </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </td>
                <td><span class="badge bg-label-primary me-1"><?php echo e($value->updated_at->format('d-m-Y')); ?></span></td>
                <td>
                  <div class="dropdown">
                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="bx bx-dots-vertical-rounded"></i>
                    </button>
                    <div class="dropdown-menu" style="">

                      <a class="dropdown-item" href="<?php echo e(route('role.edit',$value->id)); ?>"><i class="bx bx-edit-alt me-1"></i> Edit</a>




                        <form action="<?php echo e(route('role.destroy',$value->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit" class="dropdown-item show_confirm" ><i class="bx bx-trash me-1"></i> Delete</button>

                        </form>

                    </div>
                  </div>
                </td>
              </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>



        </tbody>
      </table>

    </div>
  </div>



    </div>
</div>






<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin_script'); ?>

<script>

    $(document).ready(function(){

        $('.show_confirm').click(function(event){

            let form = $(this).closest('form');
            event.preventDefault();

            Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
            if (result.isConfirmed) {

                form.submit();

                Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
                )
            }
            })


        })

    })

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\lara_adv\lara_adv\resources\views/admin/page/role/role_index.blade.php ENDPATH**/ ?>