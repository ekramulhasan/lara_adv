<?php echo e($slot); ?>

<?php /**PATH H:\lara_adv\lara_adv\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>