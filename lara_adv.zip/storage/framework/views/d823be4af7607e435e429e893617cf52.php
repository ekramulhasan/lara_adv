<?php $__env->startSection('title'); ?> backupup Data <?php $__env->stopSection(); ?>
<?php $__env->startPush('admin_style'); ?>



<?php $__env->stopPush(); ?>

<?php $__env->startSection('index'); ?>

<div class="row">
    <div class="col">


<div class="card">

    <div class="d-flex justify-content-between align-items-center my-2">

        <h5 class="card-header">Backup Index / Backup List</h5>
        

        <button type="button" class="btn btn-primary me-4" onclick="event.preventDefault(); document.getElementById('data_store').submit();">Create Backup</button>
        <form action="<?php echo e(route('backup.store')); ?>" method="post" class="d-none" id="data_store">
            <?php echo csrf_field(); ?>

        </form>

    </div>

    <div class="table-responsive text-nowrap">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>ID</th>
            <th>File Name</th>
            <th>File Size</th>
            <th>Created Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody class="table-border-bottom-0">

            <?php $__empty_1 = true; $__currentLoopData = $backup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>
                <td><strong><?php echo e($loop->index+1); ?></strong></td>
                <td><?php echo e($value['file_name']); ?></td>
                <td><?php echo e($value['file_size']); ?></td>
                <td><?php echo e($value['create_at']); ?></td>

            <td>
                  <div class="dropdown">
                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="bx bx-dots-vertical-rounded"></i>
                    </button>
                    <div class="dropdown-menu" style="">

                      <a class="dropdown-item" href="<?php echo e(route('backup.download',$value['file_name'])); ?>"><i class="bx bx-download me-1"></i> Download</a>




                        <form action="<?php echo e(route('backup.destroy',$value['file_name'])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit" class="dropdown-item show_confirm" ><i class="bx bx-trash me-1"></i> Delete</button>

                        </form>

                    </div>
                  </div>
                </td>
              </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>



        </tbody>
      </table>


    </div>
  </div>



    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin_script'); ?>

<script>

    $(document).ready(function(){

        $('.show_confirm').click(function(event){

            let form = $(this).closest('form');
            event.preventDefault();

            Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
            if (result.isConfirmed) {

                form.submit();

                Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
                )
            }
            })

        })


        $('.toggle-class').change(function () {

            var is_active = $(this).prop('checked') == true ? 1 : 0;
            var item_id = $(this).data('id');

            // console.log(is_active, item_id);

            $.ajax({

                type: "GET",
                url: "/admin/backup_isactive/"+item_id,
                dataType: "json",
                success: function (response) {

                    console.log(response);
                    Swal.fire(
                        response.message,
                        response.type
                    )

                },
                error: function (err) {

                    console.log(err);
                    Swal.fire(

                        'not permission 404 error'

                    )
                }
            });

        });

    })

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\lara_adv\lara_adv\resources\views/admin/page/backup/backup_index.blade.php ENDPATH**/ ?>