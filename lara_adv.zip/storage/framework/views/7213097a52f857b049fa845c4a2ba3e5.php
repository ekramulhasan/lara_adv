<script src="<?php echo e(asset('admin')); ?>/assets/vendor/libs/jquery/jquery.js"></script>
<script src="<?php echo e(asset('admin')); ?>/assets/vendor/libs/popper/popper.js"></script>
<script src="<?php echo e(asset('admin')); ?>/assets/vendor/js/bootstrap.js"></script>


<script src="<?php echo e(asset('admin')); ?>/assets/vendor/js/menu.js"></script>
<!-- endbuild -->

<?php echo $__env->yieldPushContent('admin_script'); ?>

<!-- Vendors JS -->




<!-- Main JS -->
<script src="<?php echo e(asset('admin')); ?>/assets/js/main.js"></script>


<script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
<?php echo Toastr::message(); ?>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- Page JS -->


<!-- Place this tag in your head or just before your close body tag. -->

<?php /**PATH H:\lara_adv\lara_adv\resources\views/admin/layout/inc/script.blade.php ENDPATH**/ ?>